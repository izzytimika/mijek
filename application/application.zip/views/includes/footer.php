<footer class="footer">
  <div class="container-fluid clearfix">
    <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2020 <a href="#">OurDevelops</a>. All rights reserved.</span>
    <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="mdi mdi-heart text-danger"></i></span>
  </div>
</footer>
<!-- partial -->
</div>
<!-- row-offcanvas ends -->
</div>
<!-- page-body-wrapper ends -->
</div>


<!-- container-scroller -->
<!-- plugins:js -->
<script src="<?= base_url(); ?>asset/node_modules/jquery/dist/jquery.min.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/popper.js/dist/umd/popper.min.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/perfect-scrollbar/dist/js/perfect-scrollbar.jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.8/js/intlTelInput-jquery.min.js"></script>
<!-- endinject -->

<!-- Plugin js for this page-->
<script src="<?= base_url(); ?>asset/node_modules/jquery-bar-rating/dist/jquery.barrating.min.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/chart.js/dist/Chart.min.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/raphael/raphael.min.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/morris.js/morris.min.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/jquery-sparkline/jquery.sparkline.min.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/datatables.net/js/jquery.dataTables.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/datatables.net-bs4/js/dataTables.bootstrap4.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/dropify/dist/js/dropify.min.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/pwstabs/assets/jquery.pwstabs.min.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/icheck/icheck.min.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/typeahead.js/dist/typeahead.bundle.min.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/select2/dist/js/select2.min.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/dragula/dist/dragula.min.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/summernote/dist/summernote-bs4.min.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/tinymce/tinymce.min.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/quill/dist/quill.min.js"></script>
<script src="<?= base_url(); ?>asset/node_modules/simplemde/dist/simplemde.min.js"></script>
<!-- End plugin js for this page-->

<!-- inject:js -->
<script src="<?= base_url(); ?>asset/js/off-canvas.js"></script>
<script src="<?= base_url(); ?>asset/js/hoverable-collapse.js"></script>
<script src="<?= base_url(); ?>asset/js/misc.js"></script>
<script src="<?= base_url(); ?>asset/js/settings.js"></script>
<script src="<?= base_url(); ?>asset/js/todolist.js"></script>

<!-- endinject -->

<!-- Custom js for this page-->
<script src="<?= base_url(); ?>asset/js/dashboard.js"></script>
<script src="<?= base_url(); ?>asset/js/data-table.js"></script>
<script src="<?= base_url(); ?>asset/js/dropify.js"></script>
<script src="<?= base_url(); ?>asset/js/tabs.js"></script>
<script src="<?= base_url(); ?>asset/js/file-upload.js"></script>
<script src="<?= base_url(); ?>asset/js/iCheck.js"></script>
<script src="<?= base_url(); ?>asset/js/typeahead.js"></script>
<script src="<?= base_url(); ?>asset/js/select2.js"></script>
<script src="<?= base_url(); ?>asset/js/dragula.js"></script>
<script src="<?= base_url(); ?>asset/js/editorDemo.js"></script>
<script src="<?= base_url(); ?>asset/js/duit.js"></script>

<!-- End custom js for this page-->
</body>

</html>